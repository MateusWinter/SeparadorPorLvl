#include <iostream>
#include "funcoes.h"

using namespace std;


int main() {
    cadastraJogador();
    formaDuplas();
    exibeDuplas();

    return 0;
}
