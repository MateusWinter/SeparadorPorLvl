#ifndef FUNÇÕES_H
#define FUNÇÕES_H

void cadastraJogador();

void formaDuplas();

void exibeDuplas();



#endif // FUNÇÕES_H
